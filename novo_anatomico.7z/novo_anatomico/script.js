const questions = [
    {
        question: "O estudo do corpo humano possibilita sua análise em diferentes níveis. Quando estudamos um conjunto de células semelhantes que desempenham a mesma função estamos analisando um:",
        options: ["tecido", "sistema", "órgão", "organismo"],
        correctAnswer: "tecido",
        Numero: "1",

    },
    {
        question: "Complete: O sangue que sai do coração é rico em ___ ? e é chamado de sangue arterial",
        options: ["Músculo", "oxigênio", "gás carbônico", "Dostoiévski"],
        correctAnswer: "oxigênio",
        Numero: "2",
    },
    {
        question: " transporte de substâncias é feito pelo?:",
        options: ["sangue", "oxigênio", "alimentos"],
        correctAnswer: "sangue",
        Numero: "3",
    },

    {
        question: "Os (?) são responsáveis pela reposição de células ósseas novas?:",
        options: ["Osteoporoses", "Osteócitos", "Osteoblastos"],
        correctAnswer: "Osteoblastos",
        Numero: "4",
    },
    {
        question: " o corpo humano possui quantos ossos?:",
        options: ["203", "100", "206"],
        correctAnswer: "206" ,
        Numero: "5",
    }

    // Adicione mais perguntas conforme necessário
];

let currentQuestionIndex = 0;
let userScore = 0;
let erradas = "";

const questionElement = document.getElementById("question");
const optionsElement = document.getElementById("options");
const nextButton = document.getElementById("next-btn");
const resultElement = document.getElementById("result");

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;

    optionsElement.innerHTML = "";
    currentQuestion.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.addEventListener("click", () => checkAnswer(index));
        optionsElement.appendChild(button);
    });
}

function checkAnswer(selectedIndex) {
    const currentQuestion = questions[currentQuestionIndex];
    if (currentQuestion.correctAnswer === currentQuestion.options[selectedIndex]) {
        userScore++;
    } else {
        erradas += `${erradas=="" ? "":", "}` + questions[currentQuestionIndex].Numero;
    }

    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    resultElement.innerHTML = `Você acertou ${userScore} de ${questions.length} perguntas. <br> ${erradas==""?"": `Você errou as seguintes questões: ${erradas}`}`;
    nextButton.style.display = "none";
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion();
    } else {
        showResult();
    }
});
// Inicialize o quiz
showQuestion();




// Referências aos elementos HTML
var openModalBtn = document.getElementById('showResult');
var closeModalBtn = document.getElementById('closeModalBtn');
var modal = document.getElementById('myModal');

// Evento de clique no botão para abrir a modal
openModalBtn.addEventListener('click', function () {
    modal.style.display = 'block';
});

// Evento de clique no botão para fechar a modal
closeModalBtn.addEventListener('click', function () {
    modal.style.display = 'none';
});

// Evento para fechar a modal ao clicar fora dela
window.addEventListener('click', function (event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
});

