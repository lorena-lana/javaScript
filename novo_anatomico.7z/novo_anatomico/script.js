const questions = [
    {
        question: "Qual é a capital do Brasil?",
        options: ["São Paulo", "Rio de Janeiro", "Brasília", "Salvador"],
        correctAnswer: "Brasília"
    },
    {
        question: "Quem escreveu 'Dom Quixote'?",
        options: ["Machado de Assis", "Cervantes", "Shakespeare", "Dostoiévski"],
        correctAnswer: "Cervantes"
    },
    {
        question: "Quem foi o primeiro presidente do Brasil ?",
        options: ["Getúlio Vargas", "Lula", "Deodoro da Fonseca"],
        correctAnswer: "Deodoro da Fonseca"
    },
    // Adicione mais perguntas conforme necessário
];

let currentQuestionIndex = 0;
let userScore = 0;

const questionElement = document.getElementById("question");
const optionsElement = document.getElementById("options");
const nextButton = document.getElementById("next-btn");
const resultElement = document.getElementById("result");

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;

    optionsElement.innerHTML = "";
    currentQuestion.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.addEventListener("click", () => checkAnswer(index));
        optionsElement.appendChild(button);
    });
}

function checkAnswer(selectedIndex) {
    const currentQuestion = questions[currentQuestionIndex];
    if (currentQuestion.correctAnswer === currentQuestion.options[selectedIndex]) {
        userScore++;
    }

    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    resultElement.textContent = `Você acertou ${userScore} de ${questions.length} perguntas.`;
    nextButton.style.display = "none";
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion();
    } else {
        showResult();
    }
});

// Inicialize o quiz
showQuestion();