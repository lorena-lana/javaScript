const form = document.querySelector("#form");
const nameInput = document.querySelector("#name");
const emailInput = document.querySelector("#email");
const passwordInput = document.querySelector("#password");
const jobSelect = document.querySelector("#job");
const messageTextarea = document.querySelector("#message");

//imprimindo no console os elementos da DOM

//console.log(form, nameInput, emailInput);

form.addEventListener("submit", (event)=>{
    event.preventDefault();
    //verifica se o nome está vazio

    if(nameInput.value ===""){
        alert("por favor, preencha seu nome!");
        return;
    }

//verifica se o email está preenchido
  if(emailInput.value === "" || !isEmailValid(emailInput.value)){
    alert("por favor, preencha seu email");
    return;
  }
  if(!validatePassword (passwordInput.value,8)){
    alert("a senha precisa ter no mínimo 8 digitos");
   
  }
  
  if(jobSelect.value === ""){
alert("por favor, selecione sua opção")
  }
  if(messageTextarea.value === ""){
    alert("por favor escreva uma menssagem")
  }
})
 
function isEmailValid(email){
    //cria um regex para validar email
    const emailRegex = new RegExp(
 //usuario12@host.com.br
 /^[a-zA-Z0-9._-]+@[a-zA-z0-9._-]+\.[a-zA-Z]{2,}$/
    );
    if(emailRegex.test(email)){
        return true;
    }
    return false;
 }
 
    function validatePassword(password, minDigits){
        if(password.length>minDigits){
                return true;
        }
        return false
    }
 



