function mostraData(){
    document.getElementById("data").innerHTML=Date();    
}

function mostraMensagem(){
alert('aperte o botão da felicidade')
}
function felicidade(){
    document.body.style.imag="red";
}