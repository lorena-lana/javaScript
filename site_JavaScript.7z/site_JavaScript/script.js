
var nada= busca



function felicidade(){
    document.body.style.background="red";
}
function procura(){
    document.getElementById("pesquisa");
    var resultado="pesquisa";
    alert(resultado , 'aperte o botão da felicidade');
}
