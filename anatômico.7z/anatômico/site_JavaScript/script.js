const MOSTRA_TELA="pergunta_A";

const primeira_pergunta ="O coração é um?";

const segunda_pergunta ="O esqueleto humano possui quantos ossos:" ;

const terceira_pergunta ="O transporte de substâncias é feito pelo:";


const primeira_alternativa_primeira_pergunta ="Um musculo";
const segunda_alternativa_primeira_pergunta ="Um osso";


const primeira_alternativa_segunda_pergunta ="300 ossos";
const segunda_alternativa_segunda_pergunta ="206 ossos";


const primeira_alternativa_terceira_pergunta ="intestino";
const segunda_alternativa_terceira_pergunta ="Sangue";

function comecar(){
    MOSTRA_TELA = primeira_alternativa_primeira_pergunta.value;
    document.write(MOSTRA_TELA);
}
