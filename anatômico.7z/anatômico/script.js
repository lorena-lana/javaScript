


/*function responder(){
    var elemento = document.getElementById("nasa");
    elemento.innerHTML = "O coração se contrai e impulsiona o sangue que circula em nosso organismo.";

    
}
*/
var perguntas = [
    {
        pergunta: "Considerando os vasos sanguíneos entre o coração e os pulmões humanos, pode-se afirmar que as:",
        resposta: "Paris"
    },
    {
        pergunta: "O corpo humano apresenta vários órgãos, os quais estão interligados formando sistema esôfago é um órgão que faz parte de qual sistema?",
        resposta: "B"
    },
    {
        pergunta: "Quantos planetas existem em nosso sistema solar?",
        resposta: "Oito"
    }
];

// Função para exibir uma pergunta na tela
function mostrarPergunta(indice) {
    var perguntaAtual = perguntas[indice];
    var respostaUsuario = prompt(perguntaAtual.pergunta);
 

    if (respostaUsuario === perguntaAtual.resposta) {
        alert("Correto!");
    } else {
        alert("Incorreto. A resposta correta é: " + perguntaAtual.resposta);
    }
}

// Chamada inicial para mostrar a primeira pergunta
mostrarPergunta(0);