

function respoder(){
    document.body.style.background="green";
}
function procura(){
    texto = document.getElementById("pesquisa").value;
    alert(texto);
}
